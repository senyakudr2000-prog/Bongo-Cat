package com.example.bongocat;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

public class CatView extends View {
 private final Paint p=new Paint(3);
 private int keyCode=-1,keyRow=1,keyCol=5,hand=0;
 private long keyUntil=0,mouseUntil=0;
 private float mx=.5f,my=.5f,scroll=0;
 private int buttons=0;
 private final int ink=0xFF171717,fur=0xFFFFFEFC,pink=0xFFFFA9B9,desk=0xFFB77B52;
 private static final String[][] K={
  {"ESC","1","2","3","4","5","6","7","8","9","0","-","=","⌫"},
  {"TAB","Q","W","E","R","T","Y","U","I","O","P","[","]","↵"},
  {"CAP","A","S","D","F","G","H","J","K","L",";","'"},
  {"⇧","Z","X","C","V","B","N","M",",",".","/","⇧"},
  {"CTRL","WIN","ALT","SPACE","ALT","FN","CTRL"}
 };
 public CatView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
 private void mapKey(int code){
  keyRow=1;keyCol=6;
  if(code>=KeyEvent.KEYCODE_A&&code<=KeyEvent.KEYCODE_Z){
   char ch=(char)('A'+code-KeyEvent.KEYCODE_A);
   String[] rows={"QWERTYUIOP","ASDFGHJKL","ZXCVBNM"};
   for(int r=0;r<3;r++){int n=rows[r].indexOf(ch);if(n>=0){keyRow=r+1;keyCol=n+(r==1?1:r==2?1:0);break;}}
  } else if(code>=KeyEvent.KEYCODE_0&&code<=KeyEvent.KEYCODE_9){keyRow=0;keyCol=code==KeyEvent.KEYCODE_0?10:code-KeyEvent.KEYCODE_1+1;}
  else switch(code){
   case KeyEvent.KEYCODE_SPACE:keyRow=4;keyCol=3;break;
   case KeyEvent.KEYCODE_ENTER:keyRow=1;keyCol=13;break;
   case KeyEvent.KEYCODE_TAB:keyRow=1;keyCol=0;break;
   case KeyEvent.KEYCODE_DEL:keyRow=0;keyCol=13;break;
   case KeyEvent.KEYCODE_SHIFT_LEFT:case KeyEvent.KEYCODE_SHIFT_RIGHT:keyRow=3;keyCol=0;break;
   case KeyEvent.KEYCODE_CTRL_LEFT:case KeyEvent.KEYCODE_CTRL_RIGHT:keyRow=4;keyCol=0;break;
   case KeyEvent.KEYCODE_ALT_LEFT:case KeyEvent.KEYCODE_ALT_RIGHT:keyRow=4;keyCol=2;break;
   default:keyRow=2;keyCol=6;
  }
  hand=keyCol<7?0:1;
 }
 public void keyPressed(int code,int action){if(action!=KeyEvent.ACTION_DOWN)return;keyCode=code;mapKey(code);keyUntil=System.currentTimeMillis()+190;invalidate();}
 public void mouseEvent(float x,float y,int action,int state,float wheel){
  mx=Math.max(0,Math.min(1,x/Math.max(1,getResources().getDisplayMetrics().widthPixels)));
  my=Math.max(0,Math.min(1,y/Math.max(1,getResources().getDisplayMetrics().heightPixels)));
  buttons=state;if(wheel!=0)scroll=wheel;
  mouseUntil=System.currentTimeMillis()+200;invalidate();
 }
 private void fill(Canvas c,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);}
 private void stroke(Canvas c,int color,float w){p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(w);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);}
 private void box(Canvas c,float l,float t,float r,float b,float rad,int color){fill(c,color);c.drawRoundRect(l,t,r,b,rad,rad,p);}
 private void outlined(Canvas c,RectF r,float rad,int color,float sw){fill(c,color);c.drawRoundRect(r,rad,rad,p);stroke(c,ink,sw);c.drawRoundRect(r,rad,rad,p);}
 private float kx(int row,int col){return 145+col*18+(row==2?7:row==3?12:0);}
 private float ky(int row){return 125+row*9;}
 @Override protected void onDraw(Canvas c){
  super.onDraw(c);c.save();c.scale(getWidth()/420f,getHeight()/190f);
  box(c,0,151,420,190,5,desk);box(c,8,137,129,159,8,0xFF444449);
  outlined(c,new RectF(43,111,88,151),18,0xFFF9F7F3,3);stroke(c,ink,2);c.drawLine(65,117,65,130,p);
  fill(c,pink);c.drawOval(53,139,61,145,p);c.drawOval(68,139,76,145,p);
  outlined(c,new RectF(139,119,410,168),6,0xFF333338,3);
  for(int r=0;r<K.length;r++)for(int col=0;col<K[r].length;col++){
   float x=kx(r,col),y=ky(r),w=K[r][col].equals("SPACE")?82:16;
   if(K[r][col].equals("SPACE"))x-=24;
   boolean active=System.currentTimeMillis()<keyUntil&&r==keyRow&&col==keyCol;
   box(c,x,y,x+w,y+7,1.8f,active?0xFFFF9FB2:0xFFF4F1ED);
   if(w<20){p.setTextSize(5);fill(c,0xFF77716E);c.drawText(K[r][col],x+3,y+5.5f,p);}
  }
  // Character: white rounded Bongo Cat, black outline and pink paw pads.
  fill(c,fur);c.drawOval(126,67,294,164,p);stroke(c,ink,5);c.drawOval(126,67,294,164,p);
  Path h=new Path();h.moveTo(137,105);h.lineTo(132,52);h.quadTo(132,42,143,49);h.quadTo(160,59,174,61);h.quadTo(209,47,242,61);h.lineTo(270,47);h.quadTo(281,42,280,55);h.lineTo(275,106);h.quadTo(272,140,207,143);h.quadTo(143,141,137,105);h.close();
  fill(c,fur);c.drawPath(h,p);stroke(c,ink,5);c.drawPath(h,p);
  fill(c,ink);c.drawOval(174,91,183,102,p);c.drawOval(231,91,240,102,p);
  fill(c,pink);c.drawCircle(207,108,4,p);stroke(c,ink,2.5f);c.drawArc(195,106,207,119,5,90,false,p);c.drawArc(207,106,219,119,85,90,false,p);
  boolean hit=System.currentTimeMillis()<keyUntil;
  for(int i=0;i<2;i++){
   float x=i==hand&&hit?Math.max(140,Math.min(355,kx(keyRow,keyCol)-9)):(i==0?155:245);
   float y=i==hand&&hit?115:126;
   outlined(c,new RectF(x,y,x+42,y+34),16,fur,4);
   fill(c,pink);c.drawOval(x+7,y+21,x+16,y+28,p);c.drawOval(x+18,y+23,x+27,y+30,p);c.drawOval(x+29,y+21,x+37,y+28,p);
  }
  // Cursor and click feedback on the mouse side.
  if(System.currentTimeMillis()<mouseUntil){
   float x=12+mx*105,y=137+my*17;
   Path cur=new Path();cur.moveTo(x,y);cur.lineTo(x+9,y+17);cur.lineTo(x+11,y+11);cur.lineTo(x+18,y+9);cur.close();
   fill(c,0xFFFFFFFF);c.drawPath(cur,p);stroke(c,ink,1.5f);c.drawPath(cur,p);
   if((buttons&MotionEvent.BUTTON_PRIMARY)!=0){fill(c,pink);c.drawCircle(65,132,7,p);}
   if((buttons&MotionEvent.BUTTON_SECONDARY)!=0){fill(c,pink);c.drawCircle(78,132,7,p);}
   if(scroll!=0){p.setTextSize(9);fill(c,ink);c.drawText(scroll>0?"↑":"↓",100,133,p);scroll=0;}
  }
  c.restore();if(System.currentTimeMillis()<keyUntil||System.currentTimeMillis()<mouseUntil)postInvalidateDelayed(35);
 }
}
