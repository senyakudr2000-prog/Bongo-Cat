package com.example.bongocat;
import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Intent;
import android.os.Build;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.accessibility.AccessibilityEvent;

public class KeyboardAccessibilityService extends AccessibilityService {
 @Override public void onServiceConnected() {
  AccessibilityServiceInfo info=getServiceInfo();
  info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
  if(Build.VERSION.SDK_INT>=34) info.setMotionEventSources(InputDevice.SOURCE_MOUSE);
  setServiceInfo(info);
 }
 @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
 @Override public void onInterrupt() {}
 @Override protected boolean onKeyEvent(KeyEvent e) {
  Intent i=new Intent(OverlayService.ACTION_KEY); i.setPackage(getPackageName());
  i.putExtra("keyCode",e.getKeyCode()); i.putExtra("keyAction",e.getAction());
  i.putExtra("keyName",KeyEvent.keyCodeToString(e.getKeyCode()).replace("KEYCODE_",""));
  sendBroadcast(i); return false;
 }
 @Override public void onMotionEvent(MotionEvent e) {
  if(Build.VERSION.SDK_INT<34) return;
  Intent i=new Intent(OverlayService.ACTION_MOUSE); i.setPackage(getPackageName());
  i.putExtra("mouseX",e.getX()); i.putExtra("mouseY",e.getY());
  i.putExtra("mouseAction",e.getAction()); i.putExtra("mouseButtons",e.getButtonState());
  i.putExtra("mouseScroll",e.getAxisValue(MotionEvent.AXIS_VSCROLL));
  sendBroadcast(i);
 }
}
