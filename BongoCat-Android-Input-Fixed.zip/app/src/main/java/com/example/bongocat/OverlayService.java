package com.example.bongocat;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;

public class OverlayService extends Service {
 public static final String ACTION_KEY="com.example.bongocat.KEY";
 public static final String ACTION_MOUSE="com.example.bongocat.MOUSE";
 private WindowManager wm; private CatView cat;
 private final BroadcastReceiver receiver=new BroadcastReceiver(){
  @Override public void onReceive(Context c,Intent i){
   if(cat==null)return;
   if(ACTION_KEY.equals(i.getAction()))
    cat.keyPressed(i.getIntExtra("keyCode",0),i.getIntExtra("keyAction",0));
   else if(ACTION_MOUSE.equals(i.getAction()))
    cat.mouseEvent(i.getFloatExtra("mouseX",0),i.getFloatExtra("mouseY",0),
      i.getIntExtra("mouseAction",0),i.getIntExtra("mouseButtons",0),i.getFloatExtra("mouseScroll",0));
  }
 };
 @Override public void onCreate(){
  super.onCreate(); if(!Settings.canDrawOverlays(this)){stopSelf();return;}
  wm=(WindowManager)getSystemService(WINDOW_SERVICE); cat=new CatView(this);
  int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
  WindowManager.LayoutParams p=new WindowManager.LayoutParams((int)(getResources().getDisplayMetrics().widthPixels*.94f),
   (int)(getResources().getDisplayMetrics().widthPixels*.43f),type,
   WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|
   WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
  p.gravity=Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL; p.y=8; wm.addView(cat,p);
  IntentFilter f=new IntentFilter();f.addAction(ACTION_KEY);f.addAction(ACTION_MOUSE);
  if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,f);
 }
 @Override public int onStartCommand(Intent i,int flags,int id){return START_STICKY;}
 @Override public void onDestroy(){try{unregisterReceiver(receiver);}catch(Exception ignored){} if(cat!=null&&wm!=null)wm.removeView(cat);super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
}
