package com.example.bongocat;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 36, 28, 28);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFFFFF8F3);

        TextView title = new TextView(this);
        title.setText("Bongo Cat");
        title.setTextSize(30);
        title.setTextColor(0xFF222222);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView info = new TextView(this);
        info.setText("1. Разреши показ поверх других приложений.\n2. Включи службу клавиатуры в специальных возможностях.\n3. Запусти кота. Подключи Bluetooth-клавиатуру и печатай.");
        info.setTextSize(16);
        info.setTextColor(0xFF444444);
        info.setPadding(0, 24, 0, 24);
        root.addView(info);

        Button overlay = new Button(this);
        overlay.setText("Разрешить поверх окон");
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        });
        root.addView(overlay, match());

        Button accessibility = new Button(this);
        accessibility.setText("Включить отслеживание клавиатуры");
        accessibility.setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessibility, match());

        Button start = new Button(this);
        start.setText("Показать Bongo Cat");
        start.setOnClickListener(v -> {
            if (Settings.canDrawOverlays(this))
                startService(new Intent(this, OverlayService.class));
            else {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            }
        });
        root.addView(start, match());

        Button stop = new Button(this);
        stop.setText("Скрыть Bongo Cat");
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));
        root.addView(stop, match());

        setContentView(root);
    }
    private LinearLayout.LayoutParams match() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = 10;
        return p;
    }
}
