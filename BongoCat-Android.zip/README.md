# Bongo Cat for Android

A 2D floating Bongo Cat desk scene for Android. It draws a cartoon cat, a full-size-style keyboard and a mouse. Hardware key-down/up events animate the keyboard paw and highlight matching keys. Mouse motion/button events are handled when Android exposes them to the accessibility service.

## Build with GitHub Actions

1. Create a GitHub repository.
2. Upload `BongoCat-Android.zip` to the repository root.
3. Create `.github/workflows/build.yml` and upload the separately supplied `build.yml` there.
4. Open the **Actions** tab and run **Build Bongo Cat APK** (or push a commit).
5. Download `BongoCat-debug-apk` from the completed workflow run's Artifacts section.

The workflow extracts the ZIP itself before building. The ZIP contains the Android project, not a prebuilt APK.

## First launch

1. Install `app-debug.apk`.
2. Open Bongo Cat and grant **Display over other apps**.
3. Open Android Accessibility settings and enable **Bongo Cat keyboard reactions**.
4. Return to Bongo Cat and tap **Start Bongo Cat**.

The accessibility service requests hardware key events and does not consume them. It sends key codes only; it does not inspect or transmit typed text.

## Mouse support limitation

On Android 14+ the app requests accessibility motion events. Android only exposes motion events that the OS/device makes available to accessibility services. Global mouse movement and click events from every third-party app are not guaranteed by Android, so mouse animation may not work in every game or launcher. The overlay itself is non-touchable so it does not steal taps/clicks from the app underneath.

## Compatibility

Configured for Android 8.0+ (API 26+) and compile SDK 35. The debug APK is unsigned for store distribution but can be installed for personal testing after allowing installation from the source you use.
