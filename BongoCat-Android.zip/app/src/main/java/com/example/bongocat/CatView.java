package com.example.bongocat;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import java.util.HashMap;
import java.util.Map;

/** Draws the complete 2D Bongo Cat desk scene and animates from hardware input. */
public class CatView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<Integer, Long> pressedKeys = new HashMap<>();
    private long keyboardPawUntil, mousePawUntil, mouseLeftUntil, mouseRightUntil, mouseMoveUntil;
    private float mouseX = -1, mouseY = -1;
    private float density;
    private final Runnable ticker = new Runnable() {
        @Override public void run() { invalidate(); handler.postDelayed(this, 32); }
    };

    public CatView(Context context) {
        super(context);
        density = getResources().getDisplayMetrics().density;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        handler.post(ticker);
    }

    private float d(float v) { return v * density; }
    private void fill(int color) { p.setColor(color); p.setStyle(Paint.Style.FILL); }
    private void round(Canvas c,int color,float l,float t,float r,float b,float radius) {
        fill(color); c.drawRoundRect(l,t,r,b,radius,radius,p);
    }
    private void stroke(Canvas c,int color,float width,float x1,float y1,float x2,float y2) {
        p.setColor(color); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(width); p.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(x1,y1,x2,y2,p); p.setStyle(Paint.Style.FILL);
    }
    private void label(Canvas c,String s,float size,int color,float x,float y) {
        fill(color); p.setTextSize(size); p.setTypeface(android.graphics.Typeface.create("sans-serif-medium",0));
        c.drawText(s,x,y,p);
    }

    public void onHardwareKey(int keyCode, int action) {
        long now = System.currentTimeMillis();
        if (action == KeyEvent.ACTION_DOWN) {
            pressedKeys.put(keyCode, now + 260);
            keyboardPawUntil = now + 190;
        } else if (action == KeyEvent.ACTION_UP) {
            pressedKeys.remove(keyCode);
        }
        invalidate();
    }

    public void onHardwareMouse(int action, int buttons, float x, float y) {
        long now = System.currentTimeMillis();
        mouseX = x; mouseY = y;
        if (action == MotionEvent.ACTION_HOVER_MOVE || action == MotionEvent.ACTION_MOVE) {
            mouseMoveUntil = now + 100;
            mousePawUntil = now + 100;
        }
        if (action == MotionEvent.ACTION_BUTTON_PRESS || action == MotionEvent.ACTION_DOWN) {
            if ((buttons & MotionEvent.BUTTON_SECONDARY) != 0) mouseRightUntil = now + 210;
            else mouseLeftUntil = now + 210;
            mousePawUntil = now + 210;
        }
        if (action == MotionEvent.ACTION_BUTTON_RELEASE || action == MotionEvent.ACTION_UP) mousePawUntil = now + 90;
        invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w=getWidth(), h=getHeight();
        if (w<=0 || h<=0) return;
        long now=System.currentTimeMillis();
        c.save();
        round(c,0xF8FFF9F3,d(5),d(5),w-d(5),h-d(5),d(19));
        label(c,"BONGO CAT",d(9),0xFF8A7880,d(14),d(18));

        // Keyboard and mouse sit side by side like the familiar Bongo Cat desk setup.
        float deskL=d(12), deskR=w-d(12), deskT=h-d(120), deskB=h-d(12);
        float mouseW=Math.min(d(56),w*.16f), gap=d(7);
        float mouseL=deskR-mouseW;
        float kbR=mouseL-gap;
        round(c,0xFF39343E,deskL,deskT,kbR,deskB,d(9));
        drawKeyboard(c,deskL,deskT,kbR,deskB,now);

        // Mouse body, wheel and click feedback.
        float mx=(mouseL+deskR)/2, my=(deskT+deskB)/2;
        round(c,0xFFBFCBDD,mouseL,deskT+d(12),deskR,deskB-d(7),d(19));
        round(c,0xFF8393A9,mx-d(1.4f),deskT+d(15),mx+d(1.4f),deskT+d(42),d(2));
        if (now<mouseLeftUntil) round(c,0xFFFFC85A,mouseL+d(4),deskT+d(15),mx-d(2),deskT+d(38),d(8));
        if (now<mouseRightUntil) round(c,0xFFFFC85A,mx+d(2),deskT+d(15),deskR-d(4),deskT+d(38),d(8));
        if (now<mouseMoveUntil && mouseX>=0) {
            fill(0xFFFF9FB1); c.drawCircle(mx,my,d(5),p);
        }

        // Cat body and face.
        float cx=w*.43f, headY=h*.275f;
        fill(0xFF51464E); c.drawOval(cx-d(48),headY+d(20),cx+d(48),deskT+d(18),p);
        fill(0xFFFFFEFC); c.drawOval(cx-d(44),headY+d(18),cx+d(44),deskT+d(13),p);
        Path ears=new Path();
        ears.moveTo(cx-d(38),headY-d(5)); ears.lineTo(cx-d(35),headY-d(42)); ears.lineTo(cx-d(7),headY-d(23)); ears.close();
        ears.moveTo(cx+d(38),headY-d(5)); ears.lineTo(cx+d(35),headY-d(42)); ears.lineTo(cx+d(7),headY-d(23)); ears.close();
        fill(0xFF51464E); c.drawPath(ears,p);
        Path inner=new Path();
        inner.moveTo(cx-d(31),headY-d(13)); inner.lineTo(cx-d(31),headY-d(33)); inner.lineTo(cx-d(16),headY-d(22)); inner.close();
        inner.moveTo(cx+d(31),headY-d(13)); inner.lineTo(cx+d(31),headY-d(33)); inner.lineTo(cx+d(16),headY-d(22)); inner.close();
        fill(0xFFFFB6C6); c.drawPath(inner,p);
        fill(0xFF51464E); c.drawCircle(cx,headY,d(44),p);
        fill(0xFFFFFEFC); c.drawCircle(cx,headY,d(40),p);
        fill(0xFF342E35); c.drawCircle(cx-d(14),headY-d(2),d(3),p); c.drawCircle(cx+d(14),headY-d(2),d(3),p);
        fill(0xFFFF91A8); c.drawOval(cx-d(4),headY+d(7),cx+d(4),headY+d(13),p);
        stroke(c,0xFF725E66,d(1.2f),cx,headY+d(12),cx-d(5),headY+d(17));
        stroke(c,0xFF725E66,d(1.2f),cx,headY+d(12),cx+d(5),headY+d(17));
        stroke(c,0xFFB9AAB0,d(1),cx-d(22),headY+d(10),cx-d(37),headY+d(7));
        stroke(c,0xFFB9AAB0,d(1),cx+d(22),headY+d(10),cx+d(37),headY+d(7));

        // One paw works the keyboard; the other reaches the mouse.
        float kbBounce=now<keyboardPawUntil?d(11):0;
        float mouseBounce=now<mousePawUntil?d(11):0;
        float pawBase=deskT+d(8);
        drawArm(c,cx-d(22),headY+d(32),cx-d(45),pawBase-kbBounce,now<keyboardPawUntil);
        drawArm(c,cx+d(22),headY+d(32),mx,pawBase-mouseBounce,now<mousePawUntil);
        c.restore();
    }

    private void drawArm(Canvas c,float x1,float y1,float x2,float y2,boolean active) {
        p.setColor(0xFF51464E); p.setStrokeWidth(d(18)); p.setStrokeCap(Paint.Cap.ROUND); c.drawLine(x1,y1,x2,y2,p);
        p.setColor(0xFFFFFEFC); p.setStrokeWidth(d(13)); c.drawLine(x1,y1,x2,y2,p);
        fill(0xFF51464E); c.drawCircle(x2,y2,d(10),p);
        fill(active?0xFFFFD16A:0xFFFFFEFC); c.drawCircle(x2,y2,d(8),p);
        stroke(c,0xFFB9AAB0,d(1),x2-d(3),y2+d(2),x2+d(3),y2+d(2));
    }

    private void drawKeyboard(Canvas c,float l,float t,float r,float b,long now) {
        float pad=d(5), gap=d(2.2f), inL=l+pad, inR=r-pad, inT=t+pad, inB=b-pad;
        String[][] rows={
            {"Esc","F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12","Del"},
            {"`","1","2","3","4","5","6","7","8","9","0","-","=","⌫"},
            {"Tab","Q","W","E","R","T","Y","U","I","O","P","[","]"},
            {"Caps","A","S","D","F","G","H","J","K","L",";","Enter"},
            {"Shift","Z","X","C","V","B","N","M",",",".","/","Shift"}
        };
        float rowH=(inB-inT-d(22)-gap*4)/5f;
        for(int ri=0;ri<rows.length;ri++) {
            String[] row=rows[ri];
            float weightSum=0;
            for(String key:row) weightSum+=keyWeight(key);
            float available=inR-inL-gap*(row.length-1);
            float y=inT+ri*(rowH+gap), x=inL;
            for(int ci=0;ci<row.length;ci++) {
                String key=row[ci];
                float kw=available*keyWeight(key)/weightSum;
                int code=keyCode(key);
                boolean down=pressedKeys.containsKey(code) && pressedKeys.get(code)>now;
                round(c,down?0xFFFFC65C:0xFFF5F0F3,x,y,x+kw,y+rowH,d(3));
                float fs=key.length()>3?d(4.5f):d(6.2f);
                label(c,key,fs,0xFF514953,x+Math.max(d(2),kw*.18f),y+rowH*.68f);
                x+=kw+gap;
            }
        }
        float spaceY=inT+4*(rowH+gap)+d(1);
        round(c,0xFFE9E1E8,inL+d(34),spaceY,inR-d(28),inB,d(3));
        label(c,"space",d(5.5f),0xFF817680,(inL+inR)/2-d(8),inB-d(3));
    }

    private float keyWeight(String key) {
        if (key.equals("Tab") || key.equals("Caps") || key.equals("Enter") || key.equals("Shift") || key.equals("⌫") || key.equals("Del") || key.equals("Esc")) return 1.55f;
        if (key.startsWith("F") && key.length()<=3) return .9f;
        return 1f;
    }

    private int keyCode(String k) {
        if (k.length()==1) {
            char ch=k.charAt(0);
            if(ch>='A'&&ch<='Z') return KeyEvent.KEYCODE_A+(ch-'A');
            if(ch>='1'&&ch<='9') return KeyEvent.KEYCODE_1+(ch-'1');
            if(ch=='0') return KeyEvent.KEYCODE_0;
            if(ch==',') return KeyEvent.KEYCODE_COMMA;
            if(ch=='.') return KeyEvent.KEYCODE_PERIOD;
            if(ch==';') return KeyEvent.KEYCODE_SEMICOLON;
            if(ch=='/') return KeyEvent.KEYCODE_SLASH;
            if(ch=='-') return KeyEvent.KEYCODE_MINUS;
            if(ch=='=') return KeyEvent.KEYCODE_EQUALS;
            if(ch=='[') return KeyEvent.KEYCODE_LEFT_BRACKET;
            if(ch==']') return KeyEvent.KEYCODE_RIGHT_BRACKET;
            if(ch=='`') return KeyEvent.KEYCODE_GRAVE;
        }
        switch(k) {
            case "Esc": return KeyEvent.KEYCODE_ESCAPE; case "Tab": return KeyEvent.KEYCODE_TAB;
            case "Del": return KeyEvent.KEYCODE_FORWARD_DEL;
            case "Caps": return KeyEvent.KEYCODE_CAPS_LOCK; case "Enter": return KeyEvent.KEYCODE_ENTER;
            case "⌫": return KeyEvent.KEYCODE_DEL; case "Shift": return KeyEvent.KEYCODE_SHIFT_LEFT;
            case " ": return KeyEvent.KEYCODE_SPACE;
            case "F1": return KeyEvent.KEYCODE_F1; case "F2": return KeyEvent.KEYCODE_F2;
            case "F3": return KeyEvent.KEYCODE_F3; case "F4": return KeyEvent.KEYCODE_F4;
            case "F5": return KeyEvent.KEYCODE_F5; case "F6": return KeyEvent.KEYCODE_F6;
            case "F7": return KeyEvent.KEYCODE_F7; case "F8": return KeyEvent.KEYCODE_F8;
            case "F9": return KeyEvent.KEYCODE_F9; case "F10": return KeyEvent.KEYCODE_F10;
            case "F11": return KeyEvent.KEYCODE_F11; case "F12": return KeyEvent.KEYCODE_F12;
            default: return -1;
        }
    }

    @Override protected void onDetachedFromWindow() { handler.removeCallbacks(ticker); super.onDetachedFromWindow(); }
}
