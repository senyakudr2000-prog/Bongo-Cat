package com.example.bongocat;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 24);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFFFFF8F0);

        TextView title = new TextView(this);
        title.setText("🐱 Bongo Cat");
        title.setTextSize(30);
        title.setTextColor(0xFF29232B);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("2D Bongo Cat: полноразмерная клавиатура, мышь и анимация двух лап.\n\n1. Разреши показ поверх других приложений.\n2. Включи службу «Bongo Cat keyboard reactions» в специальных возможностях. Она передаёт приложению только коды клавиш, не текст.\n3. Запусти плавающее окно.\n\nВажно: на Android 14+ приложение дополнительно запрашивает доступные системе события мыши через Accessibility. Система и конкретная прошивка могут не передавать движения/клики из всех приложений.");
        info.setTextSize(15);
        info.setTextColor(0xFF39333A);
        info.setPadding(0, 22, 0, 22);
        root.addView(info);

        addButton(root, "Разрешить поверх приложений", v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        });
        addButton(root, "Настроить клавиатуру и мышь", v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        addButton(root, "Запустить Bongo Cat", v -> {
            if (Settings.canDrawOverlays(this)) startService(new Intent(this, OverlayService.class));
            else startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        });
        addButton(root, "Закрыть Bongo Cat", v -> stopService(new Intent(this, OverlayService.class)));
        setContentView(root);
    }

    private void addButton(LinearLayout root, String text, android.view.View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = 8;
        root.addView(b, p);
    }
}
