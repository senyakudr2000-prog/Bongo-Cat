package com.example.bongocat;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Intent;
import android.os.Build;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.accessibility.AccessibilityEvent;

public class KeyCaptureService extends AccessibilityService {
    public static final String ACTION_INPUT = "com.example.bongocat.INPUT";
    public static final String EXTRA_KIND = "kind";
    public static final String EXTRA_CODE = "code";
    public static final String EXTRA_ACTION = "action";
    public static final String EXTRA_X = "x";
    public static final String EXTRA_Y = "y";

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null && Build.VERSION.SDK_INT >= 34) {
            info.flags |= AccessibilityServiceInfo.FLAG_SEND_MOTION_EVENTS;
            setServiceInfo(info);
        }
    }

    @Override protected boolean onKeyEvent(KeyEvent event) {
        Intent i = new Intent(ACTION_INPUT).setPackage(getPackageName());
        i.putExtra(EXTRA_KIND, "key");
        i.putExtra(EXTRA_CODE, event.getKeyCode());
        i.putExtra(EXTRA_ACTION, event.getAction());
        sendBroadcast(i);
        return false; // Let the key continue to the app/game.
    }

    // Android 14+ may deliver motion events exposed to accessibility services.
    // Android does not guarantee that global mouse events from every app are exposed.
    @Override public void onMotionEvent(MotionEvent event) {
        if (Build.VERSION.SDK_INT < 34 || event == null) return;
        int source = event.getSource();
        if ((source & android.view.InputDevice.SOURCE_MOUSE) != android.view.InputDevice.SOURCE_MOUSE
                && event.getActionMasked() != MotionEvent.ACTION_HOVER_MOVE) return;
        Intent i = new Intent(ACTION_INPUT).setPackage(getPackageName());
        i.putExtra(EXTRA_KIND, "mouse");
        i.putExtra(EXTRA_ACTION, event.getActionMasked());
        i.putExtra(EXTRA_CODE, event.getButtonState());
        i.putExtra(EXTRA_X, event.getX());
        i.putExtra(EXTRA_Y, event.getY());
        sendBroadcast(i);
    }
}
