package com.example.bongocat;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;

public class OverlayService extends Service {
    private WindowManager wm;
    private CatView cat;
    private BroadcastReceiver receiver;

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        cat = new CatView(this);
        int type = Build.VERSION.SDK_INT >= 26 ?
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, dp(300), type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        p.y = dp(8);
        wm.addView(cat, p);

        receiver = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                String kind = i.getStringExtra(KeyCaptureService.EXTRA_KIND);
                int action = i.getIntExtra(KeyCaptureService.EXTRA_ACTION, 0);
                if ("key".equals(kind)) {
                    cat.onHardwareKey(i.getIntExtra(KeyCaptureService.EXTRA_CODE, 0), action);
                } else if ("mouse".equals(kind)) {
                    cat.onHardwareMouse(action, i.getIntExtra(KeyCaptureService.EXTRA_CODE, 0),
                            i.getFloatExtra(KeyCaptureService.EXTRA_X, 0),
                            i.getFloatExtra(KeyCaptureService.EXTRA_Y, 0));
                }
            }
        };
        IntentFilter f = new IntentFilter(KeyCaptureService.ACTION_INPUT);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, f);
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onDestroy() {
        if (receiver != null) unregisterReceiver(receiver);
        if (cat != null && cat.isAttachedToWindow()) wm.removeView(cat);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
