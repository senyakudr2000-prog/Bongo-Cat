package me.realsnow;

import java.util.Arrays;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Holds the footprints lying on one block of snow. A print is packed in an int: x(10) z(10) yaw(8) type(2). */
public class DriftBlockEntity extends BlockEntity {
   public static final int MAX_PRINTS = 14;
   private int[] prints = new int[0];

   public DriftBlockEntity(BlockPos pos, BlockState state) {
      super(RealSnow.DRIFT_BE.get(), pos, state);
   }

   public int[] prints() {
      return prints;
   }

   public static int pack(float x, float z, float angle, int type) {
      int xi = Math.max(0, Math.min(1023, (int)(x * 1023.0F)));
      int zi = Math.max(0, Math.min(1023, (int)(z * 1023.0F)));
      int yaw = (int)Math.floor(angle / (Math.PI * 2.0) * 256.0) & 255;
      return xi | zi << 10 | yaw << 20 | (type & 3) << 28;
   }

   public static float x(int p) {
      return (p & 1023) / 1023.0F;
   }

   public static float z(int p) {
      return (p >> 10 & 1023) / 1023.0F;
   }

   public static float angle(int p) {
      return (p >> 20 & 255) / 256.0F * (float)(Math.PI * 2.0);
   }

   public static int type(int p) {
      return p >> 28 & 3;
   }

   public void add(int print) {
      int n = Math.min(prints.length + 1, MAX_PRINTS);
      int[] out = new int[n];
      int keep = n - 1;
      System.arraycopy(prints, prints.length - keep, out, 0, keep);
      out[n - 1] = print;
      prints = out;
      changed();
   }

   /** Snowfall and thaw slowly erase the oldest print. */
   public void fade() {
      if (prints.length > 0) {
         prints = Arrays.copyOfRange(prints, 1, prints.length);
         changed();
      }
   }

   private void changed() {
      setChanged();
      if (level != null) {
         level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
      }
   }

   @Override
   protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
      super.saveAdditional(tag, registries);
      tag.putIntArray("prints", prints);
   }

   @Override
   protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
      super.loadAdditional(tag, registries);
      prints = tag.getIntArray("prints");
   }

   @Override
   public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
      return saveCustomOnly(registries);
   }

   @Override
   public Packet<ClientGamePacketListener> getUpdatePacket() {
      return ClientboundBlockEntityDataPacket.create(this);
   }
}
