package me.realsnow.client;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import me.realsnow.DriftBlock;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.ItemOverrides;
import net.minecraft.client.renderer.block.model.ItemTransforms;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

/** Builds the snow surface from the four corner heights stored in the block state. */
public class DriftModel implements BakedModel {
   private static final List<BakedQuad> EMPTY = List.of();
   private final ConcurrentHashMap<Integer, List<BakedQuad>[]> cache = new ConcurrentHashMap<>();
   private TextureAtlasSprite sprite;

   private TextureAtlasSprite sprite() {
      if (sprite == null) {
         sprite = Minecraft.getInstance().getTextureAtlas(TextureAtlas.LOCATION_BLOCKS).apply(ResourceLocation.withDefaultNamespace("block/snow"));
      }

      return sprite;
   }

   @Override
   public List<BakedQuad> getQuads(@Nullable BlockState state, @Nullable Direction side, RandomSource random) {
      if (state == null || !state.hasProperty(DriftBlock.A)) {
         return EMPTY;
      }

      int a = state.getValue(DriftBlock.A);
      int b = state.getValue(DriftBlock.B);
      int c = state.getValue(DriftBlock.C);
      int d = state.getValue(DriftBlock.D);
      int key = a | b << 4 | c << 8 | d << 12;
      List<BakedQuad>[] lists = cache.computeIfAbsent(key, k -> build(a / 8.0F, b / 8.0F, c / 8.0F, d / 8.0F));
      return lists[side == null ? 0 : side.get3DDataValue() + 1];
   }

   @SuppressWarnings("unchecked")
   private List<BakedQuad>[] build(float ha, float hb, float hc, float hd) {
      List<BakedQuad>[] out = new List[7];
      for (int i = 0; i < 7; i++) {
         out[i] = new ObjectArrayList<>();
      }

      // top: A(0,0) B(1,0) C(0,1) D(1,1)
      out[0].add(quad(Direction.UP,
         new float[]{0, ha, 0}, new float[]{0, hc, 1}, new float[]{1, hd, 1}, new float[]{1, hb, 0}));
      if (ha + hb > 0) {
         out[Direction.NORTH.get3DDataValue() + 1].add(quad(Direction.NORTH,
            new float[]{1, 0, 0}, new float[]{0, 0, 0}, new float[]{0, ha, 0}, new float[]{1, hb, 0}));
      }

      if (hc + hd > 0) {
         out[Direction.SOUTH.get3DDataValue() + 1].add(quad(Direction.SOUTH,
            new float[]{0, 0, 1}, new float[]{1, 0, 1}, new float[]{1, hd, 1}, new float[]{0, hc, 1}));
      }

      if (ha + hc > 0) {
         out[Direction.WEST.get3DDataValue() + 1].add(quad(Direction.WEST,
            new float[]{0, 0, 0}, new float[]{0, 0, 1}, new float[]{0, hc, 1}, new float[]{0, ha, 0}));
      }

      if (hb + hd > 0) {
         out[Direction.EAST.get3DDataValue() + 1].add(quad(Direction.EAST,
            new float[]{1, 0, 1}, new float[]{1, 0, 0}, new float[]{1, hb, 0}, new float[]{1, hd, 1}));
      }

      out[Direction.DOWN.get3DDataValue() + 1].add(quad(Direction.DOWN,
         new float[]{0, 0, 1}, new float[]{0, 0, 0}, new float[]{1, 0, 0}, new float[]{1, 0, 1}));
      return out;
   }

   private BakedQuad quad(Direction face, float[] p0, float[] p1, float[] p2, float[] p3) {
      float[][] p = new float[][]{p0, p1, p2, p3};
      // make sure the winding matches the face normal
      float ux = p1[0] - p0[0];
      float uy = p1[1] - p0[1];
      float uz = p1[2] - p0[2];
      float vx = p2[0] - p0[0];
      float vy = p2[1] - p0[1];
      float vz = p2[2] - p0[2];
      float nx = uy * vz - uz * vy;
      float ny = uz * vx - ux * vz;
      float nz = ux * vy - uy * vx;
      if (nx * face.getStepX() + ny * face.getStepY() + nz * face.getStepZ() < 0) {
         p = new float[][]{p3, p2, p1, p0};
      }

      TextureAtlasSprite s = sprite();
      int[] data = new int[32];
      for (int i = 0; i < 4; i++) {
         float x = p[i][0];
         float y = p[i][1];
         float z = p[i][2];
         float fu;
         float fv;
         switch (face.getAxis()) {
            case Y -> {
               fu = x;
               fv = z;
            }
            case X -> {
               fu = z;
               fv = 1.0F - y;
            }
            default -> {
               fu = x;
               fv = 1.0F - y;
            }
         }

         float u = s.getU0() + (s.getU1() - s.getU0()) * fu;
         float v = s.getV0() + (s.getV1() - s.getV0()) * fv;
         int o = i * 8;
         data[o] = Float.floatToRawIntBits(x);
         data[o + 1] = Float.floatToRawIntBits(y);
         data[o + 2] = Float.floatToRawIntBits(z);
         data[o + 3] = -1;
         data[o + 4] = Float.floatToRawIntBits(u);
         data[o + 5] = Float.floatToRawIntBits(v);
         data[o + 6] = 0;
         data[o + 7] = 0;
      }

      return new BakedQuad(data, -1, face, s, true);
   }

   @Override
   public boolean useAmbientOcclusion() {
      return true;
   }

   @Override
   public boolean isGui3d() {
      return false;
   }

   @Override
   public boolean usesBlockLight() {
      return true;
   }

   @Override
   public boolean isCustomRenderer() {
      return false;
   }

   @Override
   public TextureAtlasSprite getParticleIcon() {
      return sprite();
   }

   @Override
   public ItemTransforms getTransforms() {
      return ItemTransforms.NO_TRANSFORMS;
   }

   @Override
   public ItemOverrides getOverrides() {
      return ItemOverrides.EMPTY;
   }
}
