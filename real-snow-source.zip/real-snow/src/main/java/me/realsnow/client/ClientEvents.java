package me.realsnow.client;

import me.realsnow.RealSnow;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.ModelEvent;

@EventBusSubscriber(modid = RealSnow.MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientEvents {
   @SubscribeEvent
   public static void onModify(ModelEvent.ModifyBakingResult event) {
      DriftModel model = new DriftModel();
      String prefix = RealSnow.MOD_ID + ":drift#";
      event.getModels().replaceAll((id, old) -> id.toString().startsWith(prefix) ? model : old);
   }

   @SubscribeEvent
   public static void onRenderers(EntityRenderersEvent.RegisterRenderers event) {
      event.registerBlockEntityRenderer(RealSnow.DRIFT_BE.get(), DriftRenderer::new);
   }
}
