package me.realsnow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import me.realsnow.DriftBlock;
import me.realsnow.DriftBlockEntity;
import me.realsnow.RealSnow;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;

/** Draws the footprints lying on a snow block, lying flat on the snow surface. */
public class DriftRenderer implements BlockEntityRenderer<DriftBlockEntity> {
   private static final ResourceLocation[] TEXTURES = new ResourceLocation[]{
      RealSnow.id("textures/misc/shoe.png"), RealSnow.id("textures/misc/paw.png"), RealSnow.id("textures/misc/track.png")
   };
   private static final float[][] SIZE = new float[][]{{0.11F, 0.16F}, {0.10F, 0.10F}, {0.10F, 0.32F}};

   public DriftRenderer(BlockEntityRendererProvider.Context context) {
   }

   private static float height(BlockState s, float fx, float fz) {
      float a = s.getValue(DriftBlock.A);
      float b = s.getValue(DriftBlock.B);
      float c = s.getValue(DriftBlock.C);
      float d = s.getValue(DriftBlock.D);
      // the top is drawn as two triangles A-D-B and A-C-D (diagonal A-D)
      float h = fx >= fz ? a + (b - a) * fx + (d - b) * fz : a + (d - c) * fx + (c - a) * fz;
      return h / 8.0F + 0.006F;
   }

   @Override
   public void render(DriftBlockEntity be, float partial, PoseStack poseStack, MultiBufferSource buffers, int light, int overlay) {
      int[] prints = be.prints();
      if (prints.length == 0) {
         return;
      }

      BlockState state = be.getBlockState();
      if (!state.hasProperty(DriftBlock.A)) {
         return;
      }

      PoseStack.Pose pose = poseStack.last();
      for (int p : prints) {
         int type = Math.min(DriftBlockEntity.type(p), 2);
         VertexConsumer vc = buffers.getBuffer(RenderType.entityTranslucent(TEXTURES[type]));
         float cx = DriftBlockEntity.x(p);
         float cz = DriftBlockEntity.z(p);
         float ang = DriftBlockEntity.angle(p);
         float fx = (float)Math.cos(ang);
         float fz = (float)Math.sin(ang);
         float rx = -fz;
         float rz = fx;
         float hw = SIZE[type][0];
         float hl = SIZE[type][1];
         float[][] uv = new float[][]{{0, 1}, {1, 1}, {1, 0}, {0, 0}};
         float[][] local = new float[][]{{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
         float[][] pos = new float[4][3];
         for (int i = 0; i < 4; i++) {
            float x = cx + rx * local[i][0] * hw + fx * local[i][1] * hl;
            float z = cz + rz * local[i][0] * hw + fz * local[i][1] * hl;
            x = Math.max(0.0F, Math.min(1.0F, x));
            z = Math.max(0.0F, Math.min(1.0F, z));
            pos[i] = new float[]{x, height(state, x, z), z};
         }

         // wind so that the quad faces up
         float ux = pos[1][0] - pos[0][0];
         float uz = pos[1][2] - pos[0][2];
         float vx = pos[2][0] - pos[0][0];
         float vz = pos[2][2] - pos[0][2];
         boolean flip = uz * vx - ux * vz < 0;
         for (int n = 0; n < 4; n++) {
            int i = flip ? 3 - n : n;
            vc.addVertex(pose, pos[i][0], pos[i][1], pos[i][2])
               .setColor(255, 255, 255, 255)
               .setUv(uv[i][0], uv[i][1])
               .setOverlay(OverlayTexture.NO_OVERLAY)
               .setLight(light)
               .setNormal(pose, 0.0F, 1.0F, 0.0F);
         }
      }
   }
}
