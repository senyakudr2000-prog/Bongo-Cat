package me.realsnow;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(RealSnow.MOD_ID)
public class RealSnow {
   public static final String MOD_ID = "realsnow";
   public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MOD_ID);
   public static final DeferredBlock<DriftBlock> DRIFT = BLOCKS.register(
      "drift",
      () -> new DriftBlock(
         BlockBehaviour.Properties.of()
            .mapColor(MapColor.SNOW)
            .strength(0.1F)
            .sound(SoundType.SNOW)
            .noOcclusion()
            .randomTicks()
            .pushReaction(PushReaction.DESTROY)
            .isViewBlocking((s, l, p) -> false)
            .isSuffocating((s, l, p) -> false)
      )
   );

   public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, MOD_ID);
   public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<DriftBlockEntity>> DRIFT_BE = BLOCK_ENTITIES.register(
      "drift", () -> BlockEntityType.Builder.of(DriftBlockEntity::new, DRIFT.get()).build(null)
   );

   public RealSnow(IEventBus modBus) {
      BLOCKS.register(modBus);
      BLOCK_ENTITIES.register(modBus);
   }

   public static ResourceLocation id(String path) {
      return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
   }
}
