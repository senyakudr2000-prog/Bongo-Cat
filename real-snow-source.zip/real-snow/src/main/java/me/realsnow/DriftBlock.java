package me.realsnow;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class DriftBlock extends Block {
   public static final IntegerProperty A = IntegerProperty.create("a", 0, SnowField.MAX);
   public static final IntegerProperty B = IntegerProperty.create("b", 0, SnowField.MAX);
   public static final IntegerProperty C = IntegerProperty.create("c", 0, SnowField.MAX);
   public static final IntegerProperty D = IntegerProperty.create("d", 0, SnowField.MAX);
   public static final IntegerProperty[] PROPS = new IntegerProperty[]{A, B, C, D};
   private static final int MAX_SLOPE = 4;
   private static final VoxelShape[] OUTLINE = new VoxelShape[SnowField.MAX + 1];
   private static final VoxelShape[] COLLISION = new VoxelShape[4 * SnowField.MAX + 1];
   private static final Direction[] SIDES = new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST};
   private static final int[][] EDGE = new int[][]{{0, 1}, {2, 3}, {0, 2}, {1, 3}};

   static {
      for (int i = 0; i <= SnowField.MAX; i++) {
         OUTLINE[i] = Shapes.box(0.0, 0.0, 0.0, 1.0, Math.max(i, 1) / 8.0, 1.0);
      }

      for (int i = 0; i < COLLISION.length; i++) {
         double h = (i / 4.0 - 2.0) / 8.0;
         COLLISION[i] = h <= 0.0 ? Shapes.empty() : Shapes.box(0.0, 0.0, 0.0, 1.0, h, 1.0);
      }
   }

   public DriftBlock(BlockBehaviour.Properties properties) {
      super(properties);
      registerDefaultState(stateDefinition.any().setValue(A, 1).setValue(B, 1).setValue(C, 1).setValue(D, 1));
   }

   @Override
   protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
      builder.add(A, B, C, D);
   }

   @Override
   protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
      return OUTLINE[SnowField.max(state)];
   }

   @Override
   protected VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
      return COLLISION[SnowField.sum(state)];
   }

   @Override
   protected VoxelShape getOcclusionShape(BlockState state, BlockGetter level, BlockPos pos) {
      return Shapes.empty();
   }

   @Override
   protected boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
      return true;
   }

   @Override
   protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState old, boolean moving) {
      if (!level.isClientSide) {
         level.scheduleTick(pos, this, 2);
      }
   }

   @Override
   protected void neighborChanged(BlockState state, Level level, BlockPos pos, Block block, BlockPos from, boolean moving) {
      if (!level.isClientSide) {
         level.scheduleTick(pos, this, 3);
      }
   }

   @Override
   protected void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
      if (entity instanceof ItemEntity || entity instanceof Projectile || entity.isSpectator()) {
         return;
      }

      double depth = SnowField.sum(state) / 4.0;
      if (entity.onGround() && depth >= 3.0) {
         double f = Math.max(0.55, 1.0 - 0.07 * (depth - 2.0));
         entity.makeStuckInBlock(state, new Vec3(f, 1.0, f));
      }

      if (!level.isClientSide && level instanceof ServerLevel sl && entity.onGround()) {
         SnowField.trample(sl, entity, pos, state);
      }
   }

   @Override
   protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
      if (!SnowField.isDrift(state)) {
         return;
      }

      if (!SnowField.supported(level, pos)) {
         collapse(level, pos, state);
         return;
      }

      boolean again = shed(level, pos, state);
      state = level.getBlockState(pos);
      if (SnowField.isDrift(state)) {
         again |= settle(level, pos, state);
      }

      if (again) {
         level.scheduleTick(pos, this, 2);
      }
   }

   /** The ground under the snow is gone: it falls into the hole. */
   private void collapse(ServerLevel level, BlockPos pos, BlockState state) {
      int volume = SnowField.sum(state);
      BlockPos below = pos.below();
      BlockState bs = level.getBlockState(below);
      level.removeBlock(pos, false);
      if (bs.getFluidState().isEmpty()) {
         SnowField.deposit(level, below, volume);
      }
   }

   /** Snow at an edge facing an unsupported column slides into it, and from there falls down. */
   private boolean shed(ServerLevel level, BlockPos pos, BlockState state) {
      boolean did = false;
      for (int i = 0; i < 4; i++) {
         BlockPos n = pos.relative(SIDES[i]);
         BlockState ns = level.getBlockState(n);
         if (!ns.getFluidState().isEmpty() || !(ns.isAir() || ns.canBeReplaced())) {
            continue;
         }

         if (SnowField.supported(level, n)) {
            continue;
         }

         state = level.getBlockState(pos);
         if (!SnowField.isDrift(state)) {
            return did;
         }

         int e0 = EDGE[i][0];
         int e1 = EDGE[i][1];
         int hi = SnowField.corner(state, e0) >= SnowField.corner(state, e1) ? e0 : e1;
         int h = SnowField.corner(state, hi);
         if (h >= 2) {
            SnowField.setVertex(level, SnowField.cornerX(pos, hi), pos.getY(), SnowField.cornerZ(pos, hi), h - 1);
            SnowField.deposit(level, n, 1);
            did = true;
         }
      }

      return did;
   }

   /** Loose snow cannot stand steeper than its angle of repose: the top of a steep edge slides down. */
   private boolean settle(ServerLevel level, BlockPos pos, BlockState state) {
      int bestDiff = MAX_SLOPE;
      int hi = -1;
      int lo = -1;
      int[][] pairs = new int[][]{{0, 1}, {2, 3}, {0, 2}, {1, 3}};
      for (int[] p : pairs) {
         int d = SnowField.corner(state, p[0]) - SnowField.corner(state, p[1]);
         if (Math.abs(d) > bestDiff) {
            bestDiff = Math.abs(d);
            hi = d > 0 ? p[0] : p[1];
            lo = d > 0 ? p[1] : p[0];
         }
      }

      if (hi < 0) {
         return false;
      }

      int y = pos.getY();
      SnowField.setVertex(level, SnowField.cornerX(pos, hi), y, SnowField.cornerZ(pos, hi), SnowField.corner(state, hi) - 1);
      SnowField.setVertex(level, SnowField.cornerX(pos, lo), y, SnowField.cornerZ(pos, lo), SnowField.corner(state, lo) + 1);
      return true;
   }

   @Override
   protected void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
      Biome biome = level.getBiome(pos).value();
      boolean snowing = level.isRaining() && biome.getPrecipitationAt(pos) == Biome.Precipitation.SNOW;
      if (snowing) {
         if (random.nextInt(3) == 0 && SnowField.max(state) < SnowField.MAX) {
            SnowField.deposit(level, pos, 1);
         }

         return;
      }

      int chance;
      if (level.getBrightness(LightLayer.BLOCK, pos) > 11) {
         chance = 1;
      } else if (biome.warmEnoughToRain(pos)) {
         chance = 4;
      } else if (level.isDay() && level.canSeeSky(pos)) {
         chance = 200;
      } else {
         return;
      }

      if (random.nextInt(chance) == 0) {
         int hi = 0;
         for (int k = 1; k < 4; k++) {
            if (SnowField.corner(state, k) > SnowField.corner(state, hi)) {
               hi = k;
            }
         }

         SnowField.setVertex(level, SnowField.cornerX(pos, hi), pos.getY(), SnowField.cornerZ(pos, hi), SnowField.corner(state, hi) - 1);
      }
   }
}
