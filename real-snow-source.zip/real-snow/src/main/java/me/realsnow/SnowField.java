package me.realsnow;

import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Snow is a height field. Every drift block stores the snow height (0..8 eighths of a block) at its four corners:
 * 0 = (x,z), 1 = (x+1,z), 2 = (x,z+1), 3 = (x+1,z+1). A corner shared by several blocks is kept equal in all of them.
 */
public final class SnowField {
   public static final int MAX = 8;

   private SnowField() {
   }

   public static boolean isDrift(BlockState s) {
      return s.is(RealSnow.DRIFT.get());
   }

   public static int corner(BlockState s, int k) {
      return s.getValue(DriftBlock.PROPS[k]);
   }

   public static BlockState make(int a, int b, int c, int d) {
      return RealSnow.DRIFT.get().defaultBlockState()
         .setValue(DriftBlock.PROPS[0], a).setValue(DriftBlock.PROPS[1], b)
         .setValue(DriftBlock.PROPS[2], c).setValue(DriftBlock.PROPS[3], d);
   }

   public static int sum(BlockState s) {
      return corner(s, 0) + corner(s, 1) + corner(s, 2) + corner(s, 3);
   }

   public static int max(BlockState s) {
      return Math.max(Math.max(corner(s, 0), corner(s, 1)), Math.max(corner(s, 2), corner(s, 3)));
   }

   public static boolean isFull(BlockState s) {
      return isDrift(s) && sum(s) == 4 * MAX;
   }

   private static boolean canHold(BlockState s) {
      return s.getFluidState().isEmpty() && (s.isAir() || s.canBeReplaced() || s.is(Blocks.SNOW));
   }

   private static void wake(Level level, BlockPos p) {
      if (level instanceof ServerLevel sl && !sl.getBlockTicks().hasScheduledTick(p, RealSnow.DRIFT.get())) {
         sl.scheduleTick(p, RealSnow.DRIFT.get(), 3);
      }
   }

   /** Sets one corner of one block. Volume is only ever moved explicitly, never created here. */
   public static void setCorner(Level level, BlockPos pos, int k, int value) {
      BlockState s = level.getBlockState(pos);
      if (!isDrift(s)) {
         return;
      }

      value = Math.max(0, Math.min(MAX, value));
      if (corner(s, k) == value) {
         return;
      }

      BlockState n = s.setValue(DriftBlock.PROPS[k], value);
      if (sum(n) == 0) {
         level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
      } else {
         level.setBlock(pos, n, 2);
         wake(level, pos);
      }
   }

   /** Makes sure a drift block exists at pos. A new block starts empty (vanilla snow keeps its layers). */
   public static boolean ensure(Level level, BlockPos pos) {
      BlockState s = level.getBlockState(pos);
      if (isDrift(s)) {
         return true;
      }

      if (!canHold(s)) {
         return false;
      }

      int n = s.is(Blocks.SNOW) ? s.getValue(SnowLayerBlock.LAYERS) : 0;
      level.setBlock(pos, make(n, n, n, n), 3);
      return true;
   }

   /** Fresh snowfall: every corner of the block rises by one (a flat layer). Returns false if it is already full. */
   public static boolean layer(Level level, BlockPos pos) {
      if (!ensure(level, pos)) {
         return false;
      }

      BlockState s = level.getBlockState(pos);
      if (!isDrift(s) || max(s) >= MAX && sum(s) == 4 * MAX) {
         return false;
      }

      for (int k = 0; k < 4; k++) {
         setCorner(level, pos, k, corner(s, k) + 1);
      }

      return true;
   }

   /** Moves snow volume into a block, filling the lowest corners first; overflow piles up. Returns what did not fit. */
   public static int deposit(Level level, BlockPos pos, int amount) {
      if (!ensure(level, pos)) {
         return amount;
      }

      while (amount > 0) {
         BlockState s = level.getBlockState(pos);
         if (!isDrift(s)) {
            return amount;
         }

         int low = 0;
         for (int k = 1; k < 4; k++) {
            if (corner(s, k) < corner(s, low)) {
               low = k;
            }
         }

         if (corner(s, low) >= MAX) {
            return deposit(level, pos.above(), amount);
         }

         setCorner(level, pos, low, corner(s, low) + 1);
         amount--;
      }

      return 0;
   }

   public static boolean supported(Level level, BlockPos pos) {
      BlockPos below = pos.below();
      BlockState b = level.getBlockState(below);
      return b.isFaceSturdy(level, below, Direction.UP) || isFull(b);
   }

   private static final class Track {
      final long[] recent = new long[12];
      int next;
      double lastX = Double.NaN;
      double lastZ;
      boolean left;

      boolean has(long p) {
         for (long r : recent) {
            if (r == p) {
               return true;
            }
         }

         return false;
      }

      void add(long p) {
         recent[next] = p;
         next = (next + 1) % recent.length;
      }
   }

   private static final Map<Entity, Track> TRACKS = Collections.synchronizedMap(new WeakHashMap<>());

   private static boolean walksOnTwoLegs(Entity e) {
      return e instanceof net.minecraft.world.entity.player.Player
         || e instanceof net.minecraft.world.entity.monster.Zombie
         || e instanceof net.minecraft.world.entity.monster.AbstractSkeleton
         || e instanceof net.minecraft.world.entity.npc.AbstractVillager
         || e instanceof net.minecraft.world.entity.monster.AbstractIllager
         || e instanceof net.minecraft.world.entity.monster.Witch
         || e instanceof net.minecraft.world.entity.monster.piglin.AbstractPiglin
         || e instanceof net.minecraft.world.entity.monster.EnderMan;
   }

   /**
    * Deep snow: every block the entity enters settles down as a whole, leaving a continuous trench with straight edges.
    * Thin snow: the entity leaves real prints (shoes, paws, tyre stripes) that are drawn on top of the surface.
    */
   public static void trample(ServerLevel level, Entity e, BlockPos pos, BlockState s) {
      double w = e.getBbWidth();
      if (!BlockPos.containing(e.getX(), pos.getY(), e.getZ()).equals(pos)) {
         return;
      }

      Track t = TRACKS.computeIfAbsent(e, k -> {
         Track nt = new Track();
         java.util.Arrays.fill(nt.recent, Long.MIN_VALUE);
         return nt;
      });
      if (Double.isNaN(t.lastX)) {
         t.lastX = e.getX();
         t.lastZ = e.getZ();
         t.add(pos.asLong());
         return;
      }

      int depth = sum(s) / 4;
      if (depth >= 4) {
         long key = pos.asLong();
         if (t.has(key)) {
            return;
         }

         t.add(key);
         for (int k = 0; k < 4; k++) {
            int c = corner(s, k);
            setCorner(level, pos, k, c >= 4 ? c - 3 : Math.max(0, c - 1));
         }

         level.sendParticles(net.minecraft.core.particles.ParticleTypes.SNOWFLAKE, e.getX(), pos.getY() + depth / 8.0, e.getZ(), 5, 0.25, 0.05, 0.25, 0.02);
         t.lastX = e.getX();
         t.lastZ = e.getZ();
         return;
      }

      if (depth < 1 || !(level.getBlockEntity(pos) instanceof DriftBlockEntity be)) {
         return;
      }

      double stride = 0.55 + 0.35 * Math.max(0.0, w - 0.6);
      double dx = e.getX() - t.lastX;
      double dz = e.getZ() - t.lastZ;
      double dist = Math.sqrt(dx * dx + dz * dz);
      if (dist < stride) {
         return;
      }

      t.lastX = e.getX();
      t.lastZ = e.getZ();
      float angle = (float)Math.atan2(dz, dx);
      float fx = (float)(dx / dist);
      float fz = (float)(dz / dist);
      float rx = -fz;
      float rz = fx;
      float bx = (float)(e.getX() - pos.getX());
      float bz = (float)(e.getZ() - pos.getZ());
      if (w >= 1.2) {
         float off = (float)(w * 0.38);
         be.add(DriftBlockEntity.pack(clamp(bx + rx * off), clamp(bz + rz * off), angle, 2));
         be.add(DriftBlockEntity.pack(clamp(bx - rx * off), clamp(bz - rz * off), angle, 2));
      } else {
         t.left = !t.left;
         float off = (float)(Math.max(w, 0.4) * 0.22) * (t.left ? -1.0F : 1.0F);
         be.add(DriftBlockEntity.pack(clamp(bx + rx * off), clamp(bz + rz * off), angle, walksOnTwoLegs(e) ? 0 : 1));
      }
   }

   private static float clamp(float v) {
      return Math.max(0.1F, Math.min(0.9F, v));
   }
}
