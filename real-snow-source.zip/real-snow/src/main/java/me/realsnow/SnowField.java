package me.realsnow;

import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Snow is a height field. Every drift block stores the snow height (0..8 eighths of a block) at its four corners:
 * 0 = (x,z), 1 = (x+1,z), 2 = (x,z+1), 3 = (x+1,z+1). A corner shared by several blocks is kept equal in all of them.
 */
public final class SnowField {
   public static final int MAX = 8;
   private static final Map<Entity, double[]> LAST_PRINT = Collections.synchronizedMap(new WeakHashMap<>());

   private SnowField() {
   }

   public static boolean isDrift(BlockState s) {
      return s.is(RealSnow.DRIFT.get());
   }

   public static int corner(BlockState s, int k) {
      return s.getValue(DriftBlock.PROPS[k]);
   }

   public static BlockState make(int a, int b, int c, int d) {
      return RealSnow.DRIFT.get().defaultBlockState()
         .setValue(DriftBlock.PROPS[0], a).setValue(DriftBlock.PROPS[1], b)
         .setValue(DriftBlock.PROPS[2], c).setValue(DriftBlock.PROPS[3], d);
   }

   public static int sum(BlockState s) {
      return corner(s, 0) + corner(s, 1) + corner(s, 2) + corner(s, 3);
   }

   public static int max(BlockState s) {
      return Math.max(Math.max(corner(s, 0), corner(s, 1)), Math.max(corner(s, 2), corner(s, 3)));
   }

   public static boolean isFull(BlockState s) {
      return isDrift(s) && sum(s) == 4 * MAX;
   }

   private static boolean canHold(BlockState s) {
      return s.getFluidState().isEmpty() && (s.isAir() || s.canBeReplaced() || s.is(Blocks.SNOW));
   }

   private static void wake(Level level, BlockPos p) {
      if (level instanceof ServerLevel sl && !sl.getBlockTicks().hasScheduledTick(p, RealSnow.DRIFT.get())) {
         sl.scheduleTick(p, RealSnow.DRIFT.get(), 3);
      }
   }

   /** Sets one corner of one block. Volume is only ever moved explicitly, never created here. */
   public static void setCorner(Level level, BlockPos pos, int k, int value) {
      BlockState s = level.getBlockState(pos);
      if (!isDrift(s)) {
         return;
      }

      value = Math.max(0, Math.min(MAX, value));
      if (corner(s, k) == value) {
         return;
      }

      BlockState n = s.setValue(DriftBlock.PROPS[k], value);
      if (sum(n) == 0) {
         level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
      } else {
         level.setBlock(pos, n, 2);
         wake(level, pos);
      }
   }

   /** Makes sure a drift block exists at pos. A new block starts empty (vanilla snow keeps its layers). */
   public static boolean ensure(Level level, BlockPos pos) {
      BlockState s = level.getBlockState(pos);
      if (isDrift(s)) {
         return true;
      }

      if (!canHold(s)) {
         return false;
      }

      int n = s.is(Blocks.SNOW) ? s.getValue(SnowLayerBlock.LAYERS) : 0;
      level.setBlock(pos, make(n, n, n, n), 3);
      return true;
   }

   /** Fresh snowfall: every corner of the block rises by one (a flat layer). Returns false if it is already full. */
   public static boolean layer(Level level, BlockPos pos) {
      if (!ensure(level, pos)) {
         return false;
      }

      BlockState s = level.getBlockState(pos);
      if (!isDrift(s) || max(s) >= MAX && sum(s) == 4 * MAX) {
         return false;
      }

      for (int k = 0; k < 4; k++) {
         setCorner(level, pos, k, corner(s, k) + 1);
      }

      return true;
   }

   /** Moves snow volume into a block, filling the lowest corners first; overflow piles up. Returns what did not fit. */
   public static int deposit(Level level, BlockPos pos, int amount) {
      if (!ensure(level, pos)) {
         return amount;
      }

      while (amount > 0) {
         BlockState s = level.getBlockState(pos);
         if (!isDrift(s)) {
            return amount;
         }

         int low = 0;
         for (int k = 1; k < 4; k++) {
            if (corner(s, k) < corner(s, low)) {
               low = k;
            }
         }

         if (corner(s, low) >= MAX) {
            return deposit(level, pos.above(), amount);
         }

         setCorner(level, pos, low, corner(s, low) + 1);
         amount--;
      }

      return 0;
   }

   public static boolean supported(Level level, BlockPos pos) {
      BlockPos below = pos.below();
      BlockState b = level.getBlockState(below);
      return b.isFaceSturdy(level, below, Direction.UP) || isFull(b);
   }

   /** Treads on the snow where the entity walks: lowers the corner nearest to each foot, leaving tracks and trenches. */
   public static void trample(ServerLevel level, Entity e, BlockPos pos, BlockState s) {
      double w = e.getBbWidth();
      double stride = 0.55 + 0.35 * Math.max(0.0, w - 0.6);
      double[] last = LAST_PRINT.get(e);
      if (last == null) {
         LAST_PRINT.put(e, new double[]{e.getX(), e.getZ()});
         return;
      }

      double dx = e.getX() - last[0];
      double dz = e.getZ() - last[1];
      double dist = Math.sqrt(dx * dx + dz * dz);
      if (dist < stride) {
         return;
      }

      last[0] = e.getX();
      last[1] = e.getZ();
      int depth = sum(s) / 4;
      int press = depth >= 4 ? 2 : 1;
      int y = pos.getY();
      if (w >= 1.2 && dist > 1.0E-4) {
         double nx = -dz / dist;
         double nz = dx / dist;
         double off = w * 0.38;
         press(level, e.getX() + nx * off, y, e.getZ() + nz * off, press);
         press(level, e.getX() - nx * off, y, e.getZ() - nz * off, press);
      } else {
         press(level, e.getX(), y, e.getZ(), press);
      }

      level.sendParticles(net.minecraft.core.particles.ParticleTypes.SNOWFLAKE, e.getX(), pos.getY() + depth / 8.0, e.getZ(), 3, 0.2, 0.05, 0.2, 0.02);
   }

   private static void press(Level level, double x, int y, double z, int amount) {
      BlockPos bp = BlockPos.containing(x, y, z);
      BlockState s = level.getBlockState(bp);
      if (!isDrift(s)) {
         return;
      }

      int k = (x - bp.getX() >= 0.5 ? 1 : 0) + (z - bp.getZ() >= 0.5 ? 2 : 0);
      if (corner(s, k) > 0) {
         setCorner(level, bp, k, corner(s, k) - amount);
      }
   }
}
