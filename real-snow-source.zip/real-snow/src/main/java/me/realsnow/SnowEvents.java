package me.realsnow;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.level.ExplosionEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;

@EventBusSubscriber(modid = RealSnow.MOD_ID)
public class SnowEvents {
   private static final int RADIUS = 40;
   private static final int ATTEMPTS = 3;

   @SubscribeEvent
   public static void onLevelTick(LevelTickEvent.Post event) {
      if (!(event.getLevel() instanceof ServerLevel level) || level.getGameTime() % 2L != 0L) {
         return;
      }

      RandomSource r = level.random;
      for (ServerPlayer p : level.players()) {
         for (int i = 0; i < ATTEMPTS; i++) {
            int x = p.getBlockX() + r.nextInt(RADIUS * 2 + 1) - RADIUS;
            int z = p.getBlockZ() + r.nextInt(RADIUS * 2 + 1) - RADIUS;
            if (!level.isLoaded(new BlockPos(x, 64, z))) {
               continue;
            }

            visit(level, level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, new BlockPos(x, 0, z)));
         }
      }
   }

   private static void visit(ServerLevel level, BlockPos top) {
      BlockPos below = top.below();
      if (level.getBlockState(top).is(Blocks.SNOW)) {
         SnowField.ensure(level, top);
      } else if (level.getBlockState(below).is(Blocks.SNOW)) {
         SnowField.ensure(level, below);
      }

      Biome biome = level.getBiome(top).value();
      if (!level.isRaining() || biome.getPrecipitationAt(top) != Biome.Precipitation.SNOW || level.getBrightness(LightLayer.BLOCK, top) > 10) {
         return;
      }

      BlockState atTop = level.getBlockState(top);
      BlockState atBelow = level.getBlockState(below);
      BlockPos target = null;
      if (SnowField.isDrift(atBelow) && SnowField.sum(atBelow) < 4 * SnowField.MAX) {
         target = below;
      } else if (SnowField.isDrift(atTop)) {
         if (SnowField.sum(atTop) < 4 * SnowField.MAX) {
            target = top;
         }
      } else if (atTop.isAir() && SnowField.supported(level, top)) {
         target = top;
      }

      if (target != null) {
         SnowField.layer(level, target);
      }
   }

   /** After an explosion the snow around the crater is told to settle: it slides and falls into the hole. */
   @SubscribeEvent
   public static void onExplosion(ExplosionEvent.Detonate event) {
      if (!(event.getLevel() instanceof ServerLevel level)) {
         return;
      }

      Set<BlockPos> around = new HashSet<>();
      for (BlockPos p : event.getAffectedBlocks()) {
         for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 2; dy++) {
               for (int dz = -1; dz <= 1; dz++) {
                  around.add(p.offset(dx, dy, dz).immutable());
               }
            }
         }
      }

      for (BlockPos p : around) {
         if (SnowField.isDrift(level.getBlockState(p))) {
            level.scheduleTick(p, RealSnow.DRIFT.get(), 4);
         }
      }
   }
}
