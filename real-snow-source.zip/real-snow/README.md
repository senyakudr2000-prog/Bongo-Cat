# Real Snow (NeoForge 1.21.1)
Snow is a height field stored in the corners of one block (`realsnow:drift`).
- Vanilla snow layers near players are converted; snowfall piles up to one block, warm biomes / light melt it, cold biomes slowly.
- Footprints and trenches: entities lower the nearest snow corners when they walk; heavy / wide entities (vehicles) leave two wheel tracks. Snowfall slowly fills tracks.
- Deep snow slows entities (up to ~45%).
- Slopes: smooth sloped surface from corner heights; steep edges slide down (angle of repose).
- Falling / explosions: snow without ground falls down, snow at a crater edge slides in and piles up.
Not included: Sable integration (no API known), per-shoe footprint decals (resolution is 1 block).
